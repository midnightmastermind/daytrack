export const selectAllTasks = (state) => state.tasks.tasks || [];
