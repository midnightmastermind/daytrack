export function findTaskByIdDeep(id, tasks) {
    if (!id || !Array.isArray(tasks)) return null;
  
    const stack = [...tasks];
    while (stack.length > 0) {
      const current = stack.pop();
      if (!current) continue;
  
      if (current._id?.toString() === id || current.tempId === id || current.id?.toString() === id) {
        return current;
      }
  
      if (Array.isArray(current.children)) {
        stack.push(...current.children);
      }
      if (Array.isArray(current.categories)) {
        stack.push(...current.categories);
      }
    }
  
    return null;
  }