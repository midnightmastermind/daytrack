import React, { useState, useEffect } from "react";
import { Button, FormGroup, InputGroup, Checkbox } from "@blueprintjs/core";
import "./NewTaskForm.css";

// Recursive component to edit a child task or category
const ChildEditor = ({ child, onChange, onDelete }) => {
  const updateField = (field, value) => {
    onChange({ ...child, [field]: value });
  };

  const updateNestedChild = (id, updatedChild) => {
    const updated = child.children.map((c) => (c.id === id ? updatedChild : c));
    onChange({ ...child, children: updated });
  };

  const addNestedChild = () => {
    const newChild = {
      id: `${Date.now()}-${Math.random()}`,
      name: "",
      properties: { checkbox: false, input: false, category: false },
      values: { checkbox: false, input: "" },
      children: [],
    };
    onChange({ ...child, children: [...(child.children || []), newChild] });
  };

  return (
    <div className="child-editor" style={{ marginLeft: "20px", marginTop: "10px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <InputGroup
          value={child.name}
          placeholder="Child name"
          onChange={(e) => updateField("name", e.target.value)}
          style={{ flex: 1 }}
        />
        <Checkbox
          label="Checkbox"
          checked={child.properties?.checkbox || false}
          onChange={(e) =>
            updateField("properties", { ...child.properties, checkbox: e.target.checked })
          }
        />
        <Checkbox
          label="Input"
          checked={child.properties?.input || false}
          onChange={(e) =>
            updateField("properties", { ...child.properties, input: e.target.checked })
          }
        />
        <Checkbox
          label="Category"
          checked={child.properties?.category || false}
          onChange={(e) =>
            updateField("properties", { ...child.properties, category: e.target.checked })
          }
        />
        <Button icon="delete" minimal onClick={onDelete} />
      </div>

      {child.properties?.category && (
        <>
          <div style={{ marginLeft: "20px", marginTop: "5px" }}>
            <Button icon="plus" minimal text="Add Nested Child" onClick={addNestedChild} />
          </div>
          <div style={{ marginLeft: "20px" }}>
            {(child.children || []).map((nested) => (
              <ChildEditor
                key={nested.id}
                child={nested}
                onChange={(updated) => updateNestedChild(nested.id, updated)}
                onDelete={() =>
                  onChange({
                    ...child,
                    children: child.children.filter((c) => c.id !== nested.id),
                  })
                }
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

const NewTaskForm = ({ task, onSave, onDelete }) => {
  const [taskName, setTaskName] = useState("");
  const [children, setChildren] = useState([]);

  useEffect(() => {
    if (task) {
      setTaskName(task.name || "");
      setChildren(task.children || []);
    } else {
      setTaskName("");
      setChildren([]);
    }
  }, [task]);

  const addChild = () => {
    const newChild = {
      id: `${Date.now()}-${Math.random()}`,
      name: "",
      properties: { checkbox: false, input: false, category: false },
      values: { checkbox: false, input: "" },
      children: [],
    };
    setChildren((prev) => [...prev, newChild]);
  };

  const updateChild = (id, updatedChild) => {
    setChildren((prev) => prev.map((c) => (c.id === id ? updatedChild : c)));
  };

  const removeChild = (id) => {
    setChildren((prev) => prev.filter((c) => c.id !== id));
  };

  const handleSave = () => {
    const tempId = task?._id || task?.tempId || `temp_${Date.now()}`;
    const newTask = {
      _id: task?._id,
      tempId,
      name: taskName,
      description: "",
      properties: { card: true, category: true },
      children,
    };
    onSave(newTask);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h3>{task ? "Edit Task" : "Create New Task"}</h3>
      <FormGroup label="Task Name" labelFor="task-name">
        <InputGroup
          id="task-name"
          placeholder="Enter task name"
          value={taskName}
          onChange={(e) => setTaskName(e.target.value)}
        />
      </FormGroup>

      <div style={{ marginTop: "20px" }}>
        <h5>Children</h5>
        <Button icon="plus" text="New Child" onClick={addChild} />
        <div style={{ marginTop: "10px" }}>
          {children.map((child) => (
            <ChildEditor
              key={child.id}
              child={child}
              onChange={(updated) => updateChild(child.id, updated)}
              onDelete={() => removeChild(child.id)}
            />
          ))}
        </div>
      </div>

      <div style={{ marginTop: "20px" }}>
        <Button intent="primary" onClick={handleSave} text={task ? "Update Task" : "Save Task"} />
        {task && (
          <Button
            intent="danger"
            onClick={() => onDelete(task)}
            text="Delete"
            style={{ marginLeft: "10px" }}
          />
        )}
      </div>
    </div>
  );
};

export default NewTaskForm;
